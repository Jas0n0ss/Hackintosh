https://github.com/corpnewt/USBMap
